
#!/bin/bash
echo "🚀 Launching All BROski♾️ UIs..."

declare -A ports=(
  [3000]="crew_control"
  [5000]="hyperfocus_studio"
  [5005]="ai_brain_hub"
  [8080]="boss_fav"
  [8877]="agent_command"
  [8888]="celebration"
  [9001]="empire_control"
)

for port in "${!ports[@]}"; do
  dir="${ports[$port]}"
  echo "⚙️ Starting ${dir} on port $port..."
  cd ~/HyperfocusZone/$dir
  nohup python3 app.py --port=$port > logs/$port.log 2>&1 &
done

echo "✅ All apps launched in background!"
