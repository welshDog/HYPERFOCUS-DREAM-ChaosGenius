
from flask import Flask, make_response, request
from flask_caching import Cache
from functools import wraps

app = Flask(__name__)

# Configure cache
app.config['CACHE_TYPE'] = 'SimpleCache'
app.config['CACHE_DEFAULT_TIMEOUT'] = 300
cache = Cache(app)

# Cache-control decorator
def cache_control(minutes=5):
    def decorator(f):
        @wraps(f)
        def wrapped(*args, **kwargs):
            response = make_response(f(*args, **kwargs))
            response.headers['Cache-Control'] = f'public, max-age={minutes * 60}'
            return response
        return wrapped
    return decorator

@app.after_request
def add_default_cache_headers(response):
    if 'Cache-Control' not in response.headers:
        response.headers['Cache-Control'] = 'public, max-age=3600'
    return response

@app.route('/')
@cache.cached(timeout=60)
def index():
    return '🌐 HyperFocusZone Flask App with Cloudflare Ultra Boost!'

@app.route('/api/data')
@cache_control(minutes=10)
def data():
    visitor_ip = request.headers.get('CF-Connecting-IP', request.remote_addr)
    return {'data': 'Ultra Cached API Response', 'ip': visitor_ip}

if __name__ == '__main__':
    app.run(debug=True)
