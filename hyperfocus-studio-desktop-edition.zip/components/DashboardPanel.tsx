
import React, { useState, useEffect } from 'react';
import { APP_NAME, WISDOM_GEM_PROMPT } from '../constants';
import { generateContent } from '../services/geminiService';
import { PanelType } from '../types';
import { ChatIcon, AnalyticsIcon, ProjectsIcon } from './IconComponents';


interface DashboardPanelProps {
  setActivePanel: (panel: PanelType) => void;
}

export const DashboardPanel: React.FC<DashboardPanelProps> = ({ setActivePanel }) => {
  const [wisdomGem, setWisdomGem] = useState<string>("Loading BROski's wisdom...");
  const [wisdomError, setWisdomError] = useState<string | null>(null);

  useEffect(() => {
    const fetchWisdom = async () => {
      try {
        setWisdomError(null);
        const response = await generateContent(WISDOM_GEM_PROMPT);
        setWisdomGem(response.text);
      } catch (error: any) {
        console.error("Failed to fetch wisdom gem:", error);
        setWisdomError("Could not load wisdom from BROski. Is the API key configured?");
        // Keep a default message if API fails
        setWisdomGem("Focus is the art of knowing what to ignore. - James Clear (paraphrased)");
      }
    };
    
    // Check if API_KEY is likely available before fetching
    if (process.env.API_KEY) {
        fetchWisdom();
    } else {
        setWisdomError("API_KEY not configured. BROski's wisdom is unavailable.");
        setWisdomGem("Set your API_KEY to unlock BROski's wisdom!");
    }
  }, []);

  const quickActions = [
    { 
      label: "💬 Quick Chat with BROski", 
      icon: <ChatIcon className="w-6 h-6 mr-2 text-purple-400" />, 
      action: () => setActivePanel(PanelType.BROSKI_CHAT),
      color: "purple"
    },
    { 
      label: "✨ New Focus Session", 
      icon: <AnalyticsIcon className="w-6 h-6 mr-2 text-green-400" />, 
      action: () => setActivePanel(PanelType.ANALYTICS) , // Placeholder, will link to pomodoro
      color: "green"
    },
    { 
      label: "📝 New Project", 
      icon: <ProjectsIcon className="w-6 h-6 mr-2 text-yellow-400" />, 
      action: () => setActivePanel(PanelType.PROJECT_TRACKING), // Placeholder
      color: "yellow"
    },
  ];


  return (
    <div className="p-6 bg-gray-800/70 rounded-lg shadow-xl border border-cyan-500/30 backdrop-blur-sm h-full flex flex-col items-center justify-center text-center">
      <h1 className="text-5xl font-bold text-cyan-400 mb-6 tracking-wider app-name-glow" style={{'--tw-shadow-color': '#00FFFF'} as React.CSSProperties}>
        Welcome to {APP_NAME}
      </h1>
      <p className="text-xl text-purple-300 mb-8 max-w-2xl">
        Your command center for hyperfocused development and creativity.
      </p>

      {/* BROski's Wisdom Gem */}
      <div className="mb-10 p-4 bg-gray-700/50 rounded-lg border border-purple-500/50 shadow-lg max-w-xl mx-auto min-h-[6rem] flex items-center justify-center">
        <p className={`text-lg italic ${wisdomError ? 'text-red-400' : 'text-cyan-300'}`}>
          {wisdomError ? wisdomError : `"${wisdomGem}"`}
        </p>
      </div>

      {/* Quick Action Buttons */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12 max-w-3xl mx-auto w-full">
        {quickActions.map(action => (
           <button 
            key={action.label}
            onClick={action.action}
            className={`
              flex flex-col items-center justify-center p-6 rounded-lg 
              bg-gray-700/60 hover:bg-gray-600/80 
              border border-${action.color}-500/50 hover:border-${action.color}-400/70
              shadow-lg hover:shadow-${action.color}-500/30
              transition-all duration-200 transform hover:scale-105
            `}
          >
            {action.icon}
            <span className={`mt-2 text-md font-semibold text-${action.color}-300`}>{action.label}</span>
          </button>
        ))}
      </div>
      
      <p className="mt-auto text-gray-400">
        Select a tool from the sidebar to continue your journey.
      </p>

      <div className="absolute bottom-4 right-4 text-xs text-gray-500">
        <p>Windows Laptop Desktop Application Project</p>
      </div>
    </div>
  );
};