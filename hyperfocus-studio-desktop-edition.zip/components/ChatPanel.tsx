
import React, { useState, useEffect, useRef, useCallback } from 'react';
import { GoogleGenAI, Chat, GenerateContentResponse } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import { ChatMessage } from '../types';
import { GEMINI_CHAT_MODEL } from '../constants';
import { SendIcon, CopyIcon, TrashIcon } from './IconComponents';

interface ChatPanelProps {
  systemInstruction: string;
}

const CodeBlock: React.FC<any> = ({ node, inline, className, children, ...props }) => {
  const match = /language-(\w+)/.exec(className || '');
  const [copied, setCopied] = useState(false);

  const handleCopy = () => {
    const codeToCopy = String(children).replace(/\n$/, '');
    navigator.clipboard.writeText(codeToCopy).then(() => {
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    }).catch(err => {
      console.error('Failed to copy code: ', err);
      // You could set an error state here if needed
    });
  };

  if (inline) {
    return <code className={`bg-gray-700 px-1 py-0.5 rounded text-sm text-purple-300 ${className || ''}`} {...props}>{children}</code>;
  }
  
  return !inline && match ? (
    <div className="code-block-wrapper group relative my-2">
      <button
        title="Copy code"
        onClick={handleCopy}
        className="absolute top-2 right-2 p-1.5 bg-gray-700 hover:bg-gray-600 rounded text-gray-300 opacity-0 group-hover:opacity-100 focus:opacity-100 transition-all duration-150 z-10"
      >
        {copied ? (
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-green-400">
            <path strokeLinecap="round" strokeLinejoin="round" d="M4.5 12.75l6 6 9-13.5" />
          </svg>
        ) : (
          <CopyIcon className="w-4 h-4" />
        )}
      </button>
      <pre className="bg-gray-800 p-3 pt-8 rounded-md text-sm overflow-x-auto w-full" {...props}>
        <code className={className}>{children}</code>
      </pre>
    </div>
  ) : (
     <pre className="bg-gray-800 p-3 rounded-md text-sm overflow-x-auto w-full my-2" {...props}>
        <code className={`block whitespace-pre-wrap ${className}`}>{children}</code>
     </pre>
  );
};


export const ChatPanel: React.FC<ChatPanelProps> = ({ systemInstruction }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const chatRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const [apiKey, setApiKey] = useState<string | null>(null);
  const [isUserTyping, setIsUserTyping] = useState(false);
  const typingTimeoutRef = useRef<number | null>(null);


  useEffect(() => {
    const key = process.env.API_KEY;
    if (key) {
      setApiKey(key);
    } else {
       console.warn("API_KEY environment variable not set. BROski Chat will be disabled.");
       setError("API_KEY not configured. BROski Chat is disabled.");
    }
  }, []);

  const initializeChat = useCallback(() => {
    if (apiKey) {
      try {
        const ai = new GoogleGenAI({ apiKey });
        chatRef.current = ai.chats.create({
          model: GEMINI_CHAT_MODEL,
          config: { systemInstruction },
        });
        setError(null); 
      } catch (e) {
        console.error("Failed to initialize Gemini AI:", e);
        setError("Failed to initialize BROski AI. Check API key and configuration.");
        chatRef.current = null;
      }
    }
  }, [apiKey, systemInstruction]);

  useEffect(() => {
    initializeChat();
  }, [initializeChat]);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = useCallback(async () => {
    if (!input.trim() || isLoading || !chatRef.current) return;
    setIsUserTyping(false); // Stop showing user typing indicator
    if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);


    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      sender: 'user',
      text: input,
      timestamp: new Date(),
    };
    setMessages((prev) => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);
    setError(null);

    const aiMessageId = (Date.now() + 1).toString();
    setMessages((prev) => [
      ...prev,
      { id: aiMessageId, sender: 'ai', text: '', timestamp: new Date(), isStreaming: true },
    ]);

    try {
      if (!chatRef.current) { 
        initializeChat();
        if (!chatRef.current) {
          throw new Error("Chat not initialized.");
        }
      }
      const stream = await chatRef.current.sendMessageStream({ message: userMessage.text });
      let currentAiText = '';
      for await (const chunk of stream) {
        currentAiText += chunk.text;
        setMessages((prev) =>
          prev.map((msg) =>
            msg.id === aiMessageId ? { ...msg, text: currentAiText, isStreaming: true } : msg
          )
        );
      }
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === aiMessageId ? { ...msg, isStreaming: false } : msg
        )
      );
    } catch (e: any) {
      console.error('Error sending message to Gemini:', e);
      const errorMessage = e.message || "An error occurred while communicating with BROski AI.";
      setError(errorMessage);
      setMessages((prev) =>
        prev.map((msg) =>
          msg.id === aiMessageId ? { ...msg, text: `Error: ${errorMessage}`, isStreaming: false, sender: 'ai' } : msg
        )
      );
    } finally {
      setIsLoading(false);
    }
  }, [input, isLoading, initializeChat]);

  const handleInputChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setInput(e.target.value);
    if (e.target.value.trim() && !isLoading) {
      setIsUserTyping(true);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
      typingTimeoutRef.current = window.setTimeout(() => {
        setIsUserTyping(false);
      }, 1500); // User considered "stopped typing" after 1.5s
    } else {
      setIsUserTyping(false);
      if (typingTimeoutRef.current) clearTimeout(typingTimeoutRef.current);
    }
  };

  const handleKeyPress = (e: React.KeyboardEvent<HTMLTextAreaElement>) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const clearChatHistory = () => {
    setMessages([]);
    initializeChat(); 
  };
  
  if (!apiKey && !error) {
    return (
      <div className="flex flex-col h-full bg-gray-800 p-6 rounded-lg shadow-xl border border-purple-500/30">
        <h2 className="text-2xl font-bold text-purple-400 mb-4">BROski♾️ AI Chat</h2>
        <div className="flex-1 flex items-center justify-center">
          <p className="text-yellow-400">Attempting to load API Key...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full bg-gray-800/70 p-4 md:p-6 rounded-lg shadow-2xl border border-purple-500/50 backdrop-blur-sm">
      <div className="flex justify-between items-center mb-4 border-b-2 border-purple-500/50 pb-2">
        <h2 className="text-2xl font-bold text-purple-400">BROski♾️ AI Chat</h2>
        <button
          onClick={clearChatHistory}
          className="p-2 text-gray-400 hover:text-red-400 transition-colors"
          title="Clear chat history"
          aria-label="Clear chat history"
        >
          <TrashIcon />
        </button>
      </div>
      
      {error && (
        <div className="bg-red-500/20 border border-red-700 text-red-300 px-4 py-3 rounded-md relative mb-4" role="alert">
          <strong className="font-bold">Error: </strong>
          <span className="block sm:inline">{error}</span>
        </div>
      )}

      <div className="flex-1 overflow-y-auto mb-4 p-2 bg-gray-900/50 rounded-md border border-gray-700/50">
        {messages.map((msg) => (
          <div
            key={msg.id}
            className={`mb-3 p-3 rounded-lg max-w-3xl ${
              msg.sender === 'user'
                ? 'bg-blue-600/40 ml-auto text-right'
                : 'bg-cyan-600/30 mr-auto text-left'
            } border ${msg.sender === 'user' ? 'border-blue-500/50' : 'border-cyan-500/50'} shadow-md`}
          >
            <div className="prose prose-sm prose-invert max-w-none text-gray-200 text-left">
              <ReactMarkdown
                remarkPlugins={[remarkGfm]}
                components={{ code: CodeBlock }}
              >
                {msg.text}
              </ReactMarkdown>
              {msg.isStreaming && <span className="inline-block w-2 h-2 ml-1 bg-gray-400 rounded-full animate-pulse"></span>}
            </div>
            <p className={`text-xs mt-1 ${msg.sender === 'user' ? 'text-blue-300/70' : 'text-cyan-300/70'}`}>
              {msg.timestamp.toLocaleTimeString()}
            </p>
          </div>
        ))}
        <div ref={messagesEndRef} />
      </div>
      
      <div className="mt-auto">
        {isUserTyping && !isLoading && <p className="text-xs text-gray-400 mb-1 ml-1">User is typing...</p>}
        <div className="flex items-center bg-gray-900/50 p-3 rounded-lg border border-gray-700/50 shadow-inner">
          <textarea
            value={input}
            onChange={handleInputChange}
            onKeyPress={handleKeyPress}
            placeholder={isLoading ? "BROski♾️ is thinking..." : "Ask BROski♾️ anything..."}
            className="flex-1 p-3 bg-gray-700/50 border border-gray-600 rounded-md focus:ring-2 focus:ring-purple-500 focus:border-purple-500 outline-none resize-none text-gray-200 placeholder-gray-400 transition-all duration-200 h-12 min-h-[3rem] max-h-32"
            rows={1}
            disabled={isLoading || !chatRef.current || !!error}
            aria-label="Chat input"
          />
          <button
            onClick={handleSendMessage}
            disabled={isLoading || !input.trim() || !chatRef.current || !!error}
            className="ml-3 p-3 bg-purple-600 hover:bg-purple-500 disabled:bg-gray-600 text-white rounded-md transition-colors duration-200 focus:outline-none focus:ring-2 focus:ring-purple-400 shadow-md hover:shadow-lg disabled:shadow-none"
            aria-label="Send message"
          >
            <SendIcon />
          </button>
        </div>
      </div>
    </div>
  );
};