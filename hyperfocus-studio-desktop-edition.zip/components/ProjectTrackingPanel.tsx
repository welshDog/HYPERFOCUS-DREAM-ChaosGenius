
import React, { useState, useEffect } from 'react';
import { ProjectsIcon } from './IconComponents';
import { Project } from '../types';
import { LOCALSTORAGE_PROJECTS_KEY } from '../constants';

const initialSampleProjects: Project[] = [
  { id: 'proj-1', name: 'HyperFocus Desktop App', status: 'In Progress', revenuePotential: '$10,000', deadline: '2024-12-31', createdAt: new Date().toISOString() },
  { id: 'proj-2', name: 'AI Resarch Paper', status: 'Planning', revenuePotential: '$5,000', deadline: '2025-03-15', createdAt: new Date().toISOString() },
  { id: 'proj-3', name: 'Neon Dreams Website', status: 'Completed', revenuePotential: '$7,500', deadline: '2024-08-01', createdAt: new Date().toISOString() },
];

export const ProjectTrackingPanel: React.FC = () => {
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    try {
      const savedProjectsRaw = localStorage.getItem(LOCALSTORAGE_PROJECTS_KEY);
      if (savedProjectsRaw) {
        setProjects(JSON.parse(savedProjectsRaw));
      } else {
        // If no projects in localStorage, use initial samples and save them
        setProjects(initialSampleProjects);
        localStorage.setItem(LOCALSTORAGE_PROJECTS_KEY, JSON.stringify(initialSampleProjects));
      }
    } catch (error) {
      console.error("Failed to load/save projects from/to localStorage:", error);
      // Fallback to initial samples if parsing fails or localStorage is unavailable
      setProjects(initialSampleProjects);
    }
  }, []);

  // TODO: Add functions to add, edit, delete projects which would also update localStorage.
  // For now, just loading and displaying.

  return (
    <div className="p-6 bg-gray-800/70 rounded-lg shadow-xl border border-yellow-500/30 backdrop-blur-sm h-full flex flex-col">
      <div className="flex items-center mb-6 pb-2 border-b-2 border-yellow-500/50">
        <ProjectsIcon className="w-8 h-8 mr-3 text-yellow-400" />
        <h2 className="text-3xl font-bold text-yellow-400">Project & Revenue Tracking</h2>
      </div>
      <div className="flex-1">
        <p className="text-gray-300 mb-6">
          Manage your projects, track revenue potential, and set goals for success. (Data is now persisted locally!)
        </p>
        
        <div className="overflow-x-auto bg-gray-700/30 p-1 rounded-md border border-gray-600/50">
          <table className="min-w-full divide-y divide-gray-600">
            <thead className="bg-gray-700/50">
              <tr>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-300 uppercase tracking-wider">Project Name</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-300 uppercase tracking-wider">Status</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-300 uppercase tracking-wider">Revenue Potential</th>
                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-yellow-300 uppercase tracking-wider">Deadline</th>
              </tr>
            </thead>
            <tbody className="bg-gray-800/50 divide-y divide-gray-700">
              {projects.map((project) => (
                <tr key={project.id} className="hover:bg-gray-700/70 transition-colors">
                  <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-200">{project.name}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm">
                     <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${project.status === 'Completed' ? 'bg-green-600/30 text-green-300 border border-green-500/50' : project.status === 'In Progress' ? 'bg-blue-600/30 text-blue-300 border border-blue-500/50' : 'bg-purple-600/30 text-purple-300 border border-purple-500/50'}`}>
                      {project.status}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{project.revenuePotential}</td>
                  <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-300">{project.deadline}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {projects.length === 0 && (
            <p className="text-center text-gray-400 mt-6">No projects found. Add your first project to get started!</p>
        )}

        <p className="mt-8 text-sm text-cyan-400 bg-cyan-500/10 p-3 rounded-md border border-cyan-500/30">
          <span className="font-bold">Enhanced:</span> Project list now persists in your browser. Full CRUD operations coming soon!
        </p>
      </div>
    </div>
  );
};