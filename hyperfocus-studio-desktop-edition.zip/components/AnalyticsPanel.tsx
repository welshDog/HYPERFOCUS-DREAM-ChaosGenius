
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { AnalyticsIcon, PlayIcon, PauseIcon, ResetIcon, SkipIcon } from './IconComponents';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { POMODORO_SETTINGS, LOCALSTORAGE_POMODORO_STATE_KEY, LOCALSTORAGE_POMODORO_SESSIONS_KEY } from '../constants';
import { PomodoroMode, PomodoroSessionLog } from '../types';

const sampleData = [
  { name: 'Mon', focus: 4, tasks: 2 },
  { name: 'Tue', focus: 3, tasks: 1 },
  { name: 'Wed', focus: 5, tasks: 3 },
  { name: 'Thu', focus: 2, tasks: 4 },
  { name: 'Fri', focus: 6, tasks: 2 },
  { name: 'Sat', focus: 1, tasks: 1 },
  { name: 'Sun', focus: 0, tasks: 0 },
];

const formatTime = (seconds: number): string => {
  const mins = Math.floor(seconds / 60);
  const secs = seconds % 60;
  return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
};

export const AnalyticsPanel: React.FC = () => {
  const [mode, setMode] = useState<PomodoroMode>('focus');
  const [timeRemaining, setTimeRemaining] = useState<number>(POMODORO_SETTINGS.focusDuration);
  const [isActive, setIsActive] = useState<boolean>(false);
  const [pomodorosCompletedThisCycle, setPomodorosCompletedThisCycle] = useState<number>(0);
  const [totalPomodorosLogged, setTotalPomodorosLogged] = useState<number>(0);
  
  const intervalRef = useRef<number | null>(null);
  const firstMountRef = useRef(true);


  // Load state from localStorage on mount
  useEffect(() => {
    try {
      const savedState = localStorage.getItem(LOCALSTORAGE_POMODORO_STATE_KEY);
      if (savedState) {
        const { mode, timeRemaining, isActive, pomodorosCompletedThisCycle } = JSON.parse(savedState);
        setMode(mode);
        setTimeRemaining(timeRemaining);
        // setIsActive(isActive); // Don't auto-start timer on load, user should initiate
        setPomodorosCompletedThisCycle(pomodorosCompletedThisCycle);
      }
      const savedSessions = localStorage.getItem(LOCALSTORAGE_POMODORO_SESSIONS_KEY);
      if (savedSessions) {
        setTotalPomodorosLogged(JSON.parse(savedSessions).length);
      }
    } catch (error) {
      console.error("Failed to load Pomodoro state from localStorage:", error);
    }
  }, []);

  // Save state to localStorage
  useEffect(() => {
    // Avoid saving on first mount if state is default and not from localStorage
    if (firstMountRef.current) {
        firstMountRef.current = false;
        // Check if current state is different from default before saving,
        // or if it was explicitly loaded from storage (which implies it should be saved)
        const savedState = localStorage.getItem(LOCALSTORAGE_POMODORO_STATE_KEY);
        if (!savedState && mode === 'focus' && timeRemaining === POMODORO_SETTINGS.focusDuration && !isActive && pomodorosCompletedThisCycle === 0) {
            return;
        }
    }
    try {
      const stateToSave = { mode, timeRemaining, isActive, pomodorosCompletedThisCycle };
      localStorage.setItem(LOCALSTORAGE_POMODORO_STATE_KEY, JSON.stringify(stateToSave));
    } catch (error) {
      console.error("Failed to save Pomodoro state to localStorage:", error);
    }
  }, [mode, timeRemaining, isActive, pomodorosCompletedThisCycle]);

  const requestNotificationPermission = useCallback(async () => {
    if (!('Notification' in window)) {
      console.warn('This browser does not support desktop notification');
      return;
    }
    if (Notification.permission !== 'granted') {
      await Notification.requestPermission();
    }
  }, []);

  useEffect(() => {
    requestNotificationPermission();
  }, [requestNotificationPermission]);

  const sendNotification = (title: string, body: string) => {
    if (Notification.permission === 'granted') {
      new Notification(title, { body, icon: '/assets/logo_icon.png' }); // Ensure you have a logo icon
    }
  };
  
  const logPomodoroSession = useCallback((sessionMode: PomodoroMode, duration: number) => {
    if (sessionMode !== 'focus') return; // Only log completed focus sessions for now

    const newLog: PomodoroSessionLog = {
      id: Date.now().toString(),
      mode: sessionMode,
      duration: POMODORO_SETTINGS.focusDuration - duration, // Actual time spent if timer was reset/skipped
      completedAt: new Date().toISOString(),
    };
    try {
      const existingLogsRaw = localStorage.getItem(LOCALSTORAGE_POMODORO_SESSIONS_KEY);
      const existingLogs: PomodoroSessionLog[] = existingLogsRaw ? JSON.parse(existingLogsRaw) : [];
      const updatedLogs = [...existingLogs, newLog];
      localStorage.setItem(LOCALSTORAGE_POMODORO_SESSIONS_KEY, JSON.stringify(updatedLogs));
      setTotalPomodorosLogged(updatedLogs.length);
    } catch (error) {
      console.error("Failed to log Pomodoro session:", error);
    }
  }, []);


  const getDurationForMode = useCallback((currentMode: PomodoroMode): number => {
    switch (currentMode) {
      case 'focus':
        return POMODORO_SETTINGS.focusDuration;
      case 'shortBreak':
        return POMODORO_SETTINGS.shortBreakDuration;
      case 'longBreak':
        return POMODORO_SETTINGS.longBreakDuration;
      default:
        return POMODORO_SETTINGS.focusDuration;
    }
  }, []);

  const switchMode = useCallback(() => {
    setIsActive(false);
    let notificationTitle = "HyperFocus Studio";
    let notificationBody = "";

    if (mode === 'focus') {
      logPomodoroSession(mode, timeRemaining); // Log before changing mode
      const newPomodorosCompleted = pomodorosCompletedThisCycle + 1;
      setPomodorosCompletedThisCycle(newPomodorosCompleted);
      if (newPomodorosCompleted % POMODORO_SETTINGS.pomodorosPerLongBreak === 0) {
        setMode('longBreak');
        setTimeRemaining(POMODORO_SETTINGS.longBreakDuration);
        notificationBody = "Focus session complete! Time for a long break.";
      } else {
        setMode('shortBreak');
        setTimeRemaining(POMODORO_SETTINGS.shortBreakDuration);
        notificationBody = "Focus session complete! Time for a short break.";
      }
    } else { // 'shortBreak' or 'longBreak'
      setMode('focus');
      setTimeRemaining(POMODORO_SETTINGS.focusDuration);
      notificationBody = "Break's over! Time to get back to focus.";
    }
    sendNotification(notificationTitle, notificationBody);
  }, [mode, pomodorosCompletedThisCycle, logPomodoroSession, timeRemaining]);


  useEffect(() => {
    if (isActive) {
      intervalRef.current = window.setInterval(() => {
        setTimeRemaining((prevTime) => {
          if (prevTime <= 1) {
            if (intervalRef.current) clearInterval(intervalRef.current);
            switchMode();
            return 0;
          }
          return prevTime - 1;
        });
      }, 1000);
    } else {
      if (intervalRef.current) clearInterval(intervalRef.current);
    }
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [isActive, switchMode]);

  const toggleTimer = () => {
    requestNotificationPermission(); // Ensure permission on interaction
    setIsActive(!isActive);
  }

  const resetTimer = () => {
    setIsActive(false);
    setTimeRemaining(getDurationForMode(mode));
  };

  const skipTimer = () => {
    if (intervalRef.current) clearInterval(intervalRef.current);
    // If skipping a focus session, still log it if some time has passed? Or only log fully completed ones?
    // For now, switchMode handles logging based on the 'mode' at the time of completion.
    // If skipping a focus session early, it won't be logged by current logic. This might be desired.
    switchMode();
  };

  const modeTextMap: Record<PomodoroMode, string> = {
    focus: "Focus Time",
    shortBreak: "Short Break",
    longBreak: "Long Break"
  };
  const modeColorMap: Record<PomodoroMode, string> = {
    focus: "border-green-500 text-green-300",
    shortBreak: "border-cyan-500 text-cyan-300",
    longBreak: "border-purple-500 text-purple-300"
  };


  return (
    <div className="p-6 bg-gray-800/70 rounded-lg shadow-xl border border-green-500/30 backdrop-blur-sm h-full flex flex-col">
      <div className="flex items-center mb-6 pb-2 border-b-2 border-green-500/50">
        <AnalyticsIcon className="w-8 h-8 mr-3 text-green-400" />
        <h2 className="text-3xl font-bold text-green-400">HyperFocus Analytics</h2>
      </div>
      
      <div className={`p-6 mb-8 rounded-lg border-2 shadow-xl bg-gray-700/50 ${modeColorMap[mode]}`}>
        <h3 className={`text-2xl font-semibold mb-4 text-center ${modeColorMap[mode].split(' ')[1]}`}>
          {modeTextMap[mode]}
        </h3>
        <div className={`text-7xl font-bold my-6 text-center tabular-nums ${modeColorMap[mode].split(' ')[1]}`}>
          {formatTime(timeRemaining)}
        </div>
        <div className="flex justify-center space-x-4">
          <button
            onClick={toggleTimer}
            className={`px-6 py-3 rounded-md font-semibold text-white transition-colors
                        ${isActive ? 'bg-yellow-500 hover:bg-yellow-600' : 'bg-green-500 hover:bg-green-600'}
                        shadow-md hover:shadow-lg w-32 flex items-center justify-center`}
            aria-label={isActive ? "Pause timer" : "Start timer"}
          >
            {isActive ? <PauseIcon className="w-5 h-5 mr-2" /> : <PlayIcon className="w-5 h-5 mr-2" />}
            {isActive ? 'Pause' : 'Start'}
          </button>
          <button
            onClick={resetTimer}
            className="px-6 py-3 rounded-md font-semibold bg-gray-500 hover:bg-gray-600 text-white transition-colors shadow-md hover:shadow-lg w-32 flex items-center justify-center"
            aria-label="Reset timer"
          >
            <ResetIcon className="w-5 h-5 mr-2" />
            Reset
          </button>
          <button
            onClick={skipTimer}
            className="px-6 py-3 rounded-md font-semibold bg-purple-500 hover:bg-purple-600 text-white transition-colors shadow-md hover:shadow-lg w-32 flex items-center justify-center"
            aria-label="Skip to next session"
          >
            <SkipIcon className="w-5 h-5 mr-2" />
            Skip
          </button>
        </div>
        <p className="text-center mt-4 text-sm text-gray-400">Pomodoros this cycle: {pomodorosCompletedThisCycle} | Total logged: {totalPomodorosLogged}</p>
      </div>

      <div className="flex-1">
        <p className="text-gray-300 mb-6">
          Track your productivity, manage focus sessions, and visualize your progress. (Chart is sample data)
        </p>
        
        <div className="h-64 md:h-80 mb-8 bg-gray-700/30 p-4 rounded-md border border-gray-600/50">
           <ResponsiveContainer width="100%" height="100%">
            <BarChart data={sampleData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#4A5568" />
              <XAxis dataKey="name" stroke="#A0AEC0" />
              <YAxis stroke="#A0AEC0" />
              <Tooltip
                contentStyle={{ backgroundColor: '#2D3748', border: '1px solid #4A5568', borderRadius: '0.375rem' }}
                itemStyle={{ color: '#E2E8F0' }}
                labelStyle={{ color: '#00FFFF', fontWeight: 'bold' }}
              />
              <Legend wrapperStyle={{ color: '#E2E8F0', paddingTop: '10px' }} />
              <Bar dataKey="focus" fill="#38B2AC" name="Focus Hours (Sample)" />
              <Bar dataKey="tasks" fill="#805AD5" name="Tasks Completed (Sample)" />
            </BarChart>
          </ResponsiveContainer>
        </div>

        <p className="text-sm text-yellow-400 bg-yellow-500/10 p-3 rounded-md border border-yellow-500/30">
          <span className="font-bold">Enhanced:</span> Pomodoro timer now has persistence, notifications, and session logging! Charts will use this data soon.
        </p>
      </div>
    </div>
  );
};