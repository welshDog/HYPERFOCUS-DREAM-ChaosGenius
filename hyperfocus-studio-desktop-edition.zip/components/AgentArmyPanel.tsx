
import React, { useState, useEffect } from 'react';
import { AgentsIcon } from './IconComponents';
import { AgentMessage } from '../types';
import { generateContent } from '../services/geminiService';
import { AGENT_CHATTER_PROMPT } from '../constants';

const MAX_AGENT_MESSAGES = 10; // Max messages to display

export const AgentArmyPanel: React.FC = () => {
  const [agentMessages, setAgentMessages] = useState<AgentMessage[]>([]);
  const [isLoadingChatter, setIsLoadingChatter] = useState<boolean>(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchAgentChatter = async () => {
      if (isLoadingChatter || !process.env.API_KEY) return; // Prevent multiple fetches or if API key missing
      
      setIsLoadingChatter(true);
      setError(null);
      try {
        const response = await generateContent(AGENT_CHATTER_PROMPT);
        const newMsg: AgentMessage = {
          id: Date.now().toString(),
          text: response.text,
          timestamp: new Date(),
        };
        setAgentMessages(prev => [newMsg, ...prev.slice(0, MAX_AGENT_MESSAGES - 1)]);
      } catch (e: any) {
        console.error("Failed to fetch agent chatter:", e);
        // Don't show an error for chatter, just log it, as it's non-critical
        // setError("Could not load agent chatter.");
      } finally {
        setIsLoadingChatter(false);
      }
    };
    
    if (!process.env.API_KEY) {
        setError("API_KEY not configured. Agent chatter is disabled.");
    } else {
        fetchAgentChatter(); // Initial fetch
        const intervalId = setInterval(fetchAgentChatter, 15000); // Fetch every 15 seconds
        return () => clearInterval(intervalId); // Cleanup on unmount
    }
  }, [isLoadingChatter]); // Added isLoadingChatter to dependency array to prevent re-triggering while loading

  return (
    <div className="p-6 bg-gray-800/70 rounded-lg shadow-xl border border-blue-500/30 backdrop-blur-sm h-full flex flex-col">
      <div className="flex items-center mb-6 pb-2 border-b-2 border-blue-500/50">
        <AgentsIcon className="w-8 h-8 mr-3 text-blue-400" />
        <h2 className="text-3xl font-bold text-blue-400">Agent Army Simulation</h2>
      </div>
      
      <div className="mb-6">
        <h3 className="text-xl text-cyan-300 mb-2">Agent Comms Stream:</h3>
        {error && <p className="text-red-400 text-sm mb-2">{error}</p>}
        <div className="h-48 bg-gray-900/50 p-3 rounded-md border border-gray-700/50 overflow-y-auto flex flex-col-reverse">
          {agentMessages.length === 0 && !isLoadingChatter && !error && (
            <p className="text-gray-500 italic">No agent communications yet...</p>
          )}
          {isLoadingChatter && agentMessages.length === 0 && (
             <p className="text-gray-500 italic">Initializing comms link...</p>
          )}
          {agentMessages.map(msg => (
            <div key={msg.id} className="text-sm text-gray-300 mb-1.5 border-b border-gray-700/30 pb-1.5 last:border-b-0 last:mb-0">
              <span className="text-blue-400/80 mr-2 text-xs">[{msg.timestamp.toLocaleTimeString()}]</span>
              {msg.text}
            </div>
          ))}
        </div>
      </div>

      <div className="flex-1 flex flex-col items-center justify-center text-center">
        <p className="text-lg text-gray-300 mb-4">
          Visualizing your 93 AI agents network.
        </p>
        
        <div className="grid grid-cols-5 md:grid-cols-10 gap-2 p-2 max-w-md mx-auto">
          {Array.from({ length: 30 }).map((_, i) => ( // Displaying 30 for brevity
            <div 
              key={i} 
              className="w-10 h-10 bg-blue-600/30 border border-blue-500/60 rounded-full flex items-center justify-center animate-pulse" 
              style={{animationDelay: `${Math.random() * 1000}ms`, animationDuration: `${1500 + Math.random() * 1000}ms`}}
              title={`Agent Unit ${i + 1}`}
            >
              <div className="w-3 h-3 bg-cyan-400 rounded-full opacity-70"></div>
            </div>
          ))}
        </div>
        <p className="mt-6 text-sm text-yellow-400 bg-yellow-500/10 p-3 rounded-md border border-yellow-500/30">
          <span className="font-bold">Active Simulation:</span> Agent comms are live. Dashboard under construction.
        </p>
      </div>
    </div>
  );
};