
import React from 'react';
import { PanelType } from '../types';
import { APP_NAME } from '../constants';
import { DashboardIcon, ChatIcon, AgentsIcon, AnalyticsIcon, ProjectsIcon, FilesIcon, HyperFocusLogo } from './IconComponents';

interface SidebarProps {
  activePanel: PanelType;
  setActivePanel: (panel: PanelType) => void;
  isFocusMode: boolean;
  setIsFocusMode: (isFocusMode: boolean) => void;
  className?: string;
}

const NavItem: React.FC<{
  icon: React.ReactNode;
  label: string;
  panel: PanelType;
  isActive: boolean;
  onClick: () => void;
  isFocusMode: boolean;
}> = ({ icon, label, isActive, onClick, isFocusMode }) => {
  return (
    <button
      onClick={onClick}
      className={`
        flex items-center w-full px-4 py-3 text-sm transition-colors duration-200 nav-item-hf
        ${isActive
          ? 'bg-cyan-600/30 text-cyan-300 border-r-4 border-cyan-400'
          : 'text-gray-400 hover:text-cyan-400 hover:bg-gray-700/50'
        }
        ${isFocusMode && isActive ? 'pl-3' : ''} // Slightly adjust padding in focus mode for active item
        ${isFocusMode && !isActive ? 'justify-center' : ''}
      `}
      aria-current={isActive ? 'page' : undefined}
      title={label}
    >
      <span className={`mr-3 ${isFocusMode ? 'mr-0' : ''}`}>{icon}</span>
      <span className="nav-label">{label}</span>
    </button>
  );
};

export const Sidebar: React.FC<SidebarProps> = ({ activePanel, setActivePanel, isFocusMode, setIsFocusMode, className }) => {
  const navItems = [
    { icon: <DashboardIcon />, label: 'Dashboard', panel: PanelType.DASHBOARD },
    { icon: <ChatIcon />, label: 'BROski♾️ Chat', panel: PanelType.BROSKI_CHAT },
    { icon: <AgentsIcon />, label: 'Agent Army', panel: PanelType.AGENT_ARMY },
    { icon: <AnalyticsIcon />, label: 'Analytics', panel: PanelType.ANALYTICS },
    { icon: <ProjectsIcon />, label: 'Projects', panel: PanelType.PROJECT_TRACKING },
    { icon: <FilesIcon />, label: 'File Manager', panel: PanelType.FILE_MANAGER },
  ];

  return (
    <aside className={`bg-gray-800 text-gray-100 flex flex-col border-r border-gray-700 shadow-lg shadow-cyan-500/10 transition-all duration-300 ease-in-out ${isFocusMode ? 'sidebar-collapsed w-20' : 'w-64'} ${className}`}>
      <div className={`flex items-center justify-center h-20 border-b border-gray-700 shadow-md shadow-purple-500/10 ${isFocusMode ? 'px-2' : ''}`}>
        <HyperFocusLogo className={`w-10 h-10 hyperfocus-logo-hf ${isFocusMode ? '' : 'mr-2'}`} />
        <h1 className={`text-xl font-bold text-cyan-400 tracking-wider app-name-glow app-name-text ${isFocusMode ? 'hidden' : 'block'}`} style={{'--tw-shadow-color': '#00FFFF'} as React.CSSProperties}>{APP_NAME}</h1>
      </div>
      <nav className="flex-1 mt-6 space-y-1">
        {navItems.map((item) => (
          <NavItem
            key={item.panel}
            icon={item.icon}
            label={item.label}
            panel={item.panel}
            isActive={activePanel === item.panel}
            onClick={() => setActivePanel(item.panel)}
            isFocusMode={isFocusMode}
          />
        ))}
      </nav>
      <div className={`p-4 border-t border-gray-700 ${isFocusMode ? 'flex justify-center' : ''}`}>
        <label htmlFor="focus-toggle" className="flex items-center cursor-pointer select-none">
          <div className="relative">
            <input 
              type="checkbox" 
              id="focus-toggle" 
              className="sr-only" 
              checked={isFocusMode} 
              onChange={() => setIsFocusMode(!isFocusMode)} 
              aria-label="Toggle HyperFocus Mode"
            />
            <div className={`block w-10 h-6 rounded-full transition-colors ${isFocusMode ? 'bg-cyan-500' : 'bg-gray-600'}`}></div>
            <div className={`dot absolute left-1 top-1 bg-white w-4 h-4 rounded-full transition-transform ${isFocusMode ? 'transform translate-x-full' : ''}`}></div>
          </div>
          <div className={`ml-3 text-sm text-gray-300 focus-mode-label ${isFocusMode ? 'hidden' : 'block'}`}>HyperFocus Mode</div>
        </label>
      </div>
      <div className={`p-4 border-t border-gray-700 text-xs text-gray-500 footer-text ${isFocusMode ? 'hidden' : 'block'}`}>
        <p>&copy; {new Date().getFullYear()} Chief Lyndz</p>
        <p>HyperFocus Studio Desktop Edition</p>
      </div>
    </aside>
  );
};