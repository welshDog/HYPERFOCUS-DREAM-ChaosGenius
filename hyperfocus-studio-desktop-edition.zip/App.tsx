
import React, { useState, useCallback } from 'react';
import { Sidebar } from './components/Sidebar';
import { ChatPanel } from './components/ChatPanel';
import { AgentArmyPanel } from './components/AgentArmyPanel';
import { AnalyticsPanel } from './components/AnalyticsPanel';
import { ProjectTrackingPanel } from './components/ProjectTrackingPanel';
import { FileManagerPanel } from './components/FileManagerPanel';
import { PanelType } from './types';
import { BROSKI_SYSTEM_INSTRUCTION } from './constants';
import { DashboardPanel } from './components/DashboardPanel';

const App: React.FC = () => {
  const [activePanel, setActivePanel] = useState<PanelType>(PanelType.DASHBOARD);
  const [isFocusMode, setIsFocusMode] = useState<boolean>(false);

  const renderPanel = useCallback((): React.ReactNode => {
    switch (activePanel) {
      case PanelType.DASHBOARD:
        return <DashboardPanel setActivePanel={setActivePanel} />;
      case PanelType.BROSKI_CHAT:
        return <ChatPanel systemInstruction={BROSKI_SYSTEM_INSTRUCTION} />;
      case PanelType.AGENT_ARMY:
        return <AgentArmyPanel />;
      case PanelType.ANALYTICS:
        return <AnalyticsPanel />;
      case PanelType.PROJECT_TRACKING:
        return <ProjectTrackingPanel />;
      case PanelType.FILE_MANAGER:
        return <FileManagerPanel />;
      default:
        return <DashboardPanel setActivePanel={setActivePanel} />;
    }
  }, [activePanel]);

  return (
    <div className={`flex h-screen bg-gray-900 font-mono ${isFocusMode ? 'hyperfocus-active-bg' : ''}`}>
      <Sidebar 
        activePanel={activePanel} 
        setActivePanel={setActivePanel}
        isFocusMode={isFocusMode}
        setIsFocusMode={setIsFocusMode}
        className="sidebar-hf-allow" // Prevent sidebar from being overly dimmed by general rules
      />
      <main className={`flex-1 p-6 overflow-y-auto transition-all duration-300 ease-in-out ${isFocusMode ? 'main-content-expanded' : ''}`}>
        <div key={activePanel} className="animate-fadeIn h-full">
          {renderPanel()}
        </div>
      </main>
    </div>
  );
};

export default App;