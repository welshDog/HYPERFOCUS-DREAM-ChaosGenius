
import { GoogleGenAI, Chat, GenerateContentResponse, GenerateContentParameters } from '@google/genai';
import { GEMINI_CHAT_MODEL } from '../constants';

let ai: GoogleGenAI | null = null;

const getAiInstance = (): GoogleGenAI => {
  if (!ai) {
    const apiKey = process.env.API_KEY;
    if (!apiKey) {
      // In a browser context, process.env.API_KEY might not be directly available
      // without a build tool like Vite or Webpack.
      // For this sandbox, we assume it's set globally or handled by the environment.
      console.warn("API_KEY process.env variable is not set. Gemini API calls may fail if not provided elsewhere.");
      // Fallback or error handling strategy might be needed here depending on env.
    }
    // The API key MUST be obtained exclusively from the environment variable `process.env.API_KEY`.
    // The application must not ask the user for it under any circumstances.
    ai = new GoogleGenAI({ apiKey: process.env.API_KEY || "" });
  }
  return ai;
};

export const createGeminiChat = (systemInstruction: string): Chat => {
  const currentAi = getAiInstance();
  return currentAi.chats.create({
    model: GEMINI_CHAT_MODEL,
    config: {
      systemInstruction: systemInstruction,
    },
  });
};

export const sendChatMessageStream = async (chat: Chat, message: string): Promise<AsyncIterable<GenerateContentResponse>> => {
  try {
    const result = await chat.sendMessageStream({ message });
    return result;
  } catch (error) {
    console.error("Error in sendChatMessageStream:", error);
    throw error; // Re-throw to be handled by caller
  }
};

export const generateContent = async (promptInput: string | GenerateContentParameters): Promise<GenerateContentResponse> => {
  const currentAi = getAiInstance();
  try {
    const request: { model: string; contents: any; config?: any } = {
        model: GEMINI_CHAT_MODEL, // Default model, can be overridden by promptInput if it's an object
        contents: '',
    };

    if (typeof promptInput === 'string') {
        request.contents = promptInput;
    } else {
        request.contents = promptInput.contents;
        if (promptInput.model) { // Allow overriding model
            request.model = promptInput.model;
        }
        if (promptInput.config) {
            request.config = promptInput.config;
        }
    }
    
    const response = await currentAi.models.generateContent(request);
    return response;
  } catch (error) {
    console.error("Error in generateContent:", error);
    throw error;
  }
};

// Example of how ChatPanel.tsx currently handles its own Gemini instance and chat session:
// This comment is to acknowledge that ChatPanel.tsx has its own direct Gemini API usage.
// For a larger application, centralizing API interaction logic as shown above is a good practice.
// However, for components with complex stateful interactions like a streaming chat, 
// managing the Chat instance within the component can sometimes be more straightforward.