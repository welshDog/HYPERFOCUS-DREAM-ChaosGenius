
export enum PanelType {
  DASHBOARD = 'DASHBOARD',
  BROSKI_CHAT = 'BROSKI_CHAT',
  AGENT_ARMY = 'AGENT_ARMY',
  ANALYTICS = 'ANALYTICS',
  PROJECT_TRACKING = 'PROJECT_TRACKING',
  FILE_MANAGER = 'FILE_MANAGER',
}

export interface ChatMessage {
  id: string;
  sender: 'user' | 'ai';
  text: string;
  timestamp: Date;
  isStreaming?: boolean;
}

export type PomodoroMode = 'focus' | 'shortBreak' | 'longBreak';

export interface PomodoroSessionLog {
  id: string;
  mode: PomodoroMode; // Typically 'focus' as we log completed focus sessions
  duration: number; // Duration in seconds
  completedAt: string; // ISO string date
}

export interface Project {
  id: string; // Use string for IDs for easier generation (e.g., UUID)
  name: string;
  status: 'Planning' | 'In Progress' | 'Completed' | 'On Hold';
  revenuePotential: string; // Keep as string for now, could be number
  deadline: string; // ISO string date or YYYY-MM-DD
  description?: string;
  createdAt: string; // ISO string date
}

export interface AgentMessage {
  id: string;
  text: string;
  timestamp: Date;
  sourceAgent?: string; // Optional: "Agent Σ-7"
}
