
export const APP_NAME = "HyperFocus Studio";
export const GEMINI_CHAT_MODEL = "gemini-2.5-flash-preview-04-17";
export const BROSKI_SYSTEM_INSTRUCTION = "You are BROski♾️, an AI assistant for developers and creative professionals. You are part of HyperFocus Studio. Be helpful, encouraging, and use a slightly energetic and tech-savvy tone. Format your responses using markdown where appropriate (e.g., code blocks, lists).";

export const CYBER_PURPLE = '#8A2BE2'; // BlueViolet
export const NEON_CYAN = '#00FFFF';
export const NEON_BLUE = '#007BFF';
export const DARK_BG = '#121212'; // Very dark grey, almost black
export const PANEL_BG = '#1E1E1E'; // Slightly lighter dark grey

export const POMODORO_SETTINGS = {
  focusDuration: 25 * 60, // 25 minutes in seconds
  shortBreakDuration: 5 * 60, // 5 minutes
  longBreakDuration: 15 * 60, // 15 minutes
  pomodorosPerLongBreak: 4, // Number of focus sessions before a long break
};

export const WISDOM_GEM_PROMPT = "Generate a concise, insightful, and motivating productivity tip or a tech-related fun fact for a software developer. Keep it under 150 characters. Be punchy and encouraging, like a wise, friendly AI sidekick.";

export const AGENT_CHATTER_PROMPT = `Generate a short, thematic status update or communication snippet from a fictional AI agent within a collective called the "Agent Army". The tone should be slightly cyberpunk, techy, and professional. Examples: 
- "Agent Σ-7: Quantum flux recalibrated. Efficiency up 3.7%."
- "Agent β-42: Anomaly detected in Sector Gamma. Investigating..."
- "Comms Relay: All units, Project Chimera is a go."
- "Agent Ω-1: Data stream integrity verified. Nominal parameters."
- "Agent α-Prime: Threat signature neutralized. Grid secure."
Keep it under 100 characters.`;

// localStorage Keys
export const LOCALSTORAGE_POMODORO_STATE_KEY = 'hfs_pomodoroState';
export const LOCALSTORAGE_POMODORO_SESSIONS_KEY = 'hfs_pomodoroSessions';
export const LOCALSTORAGE_PROJECTS_KEY = 'hfs_projects';
