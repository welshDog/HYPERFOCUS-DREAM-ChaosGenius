# broski_money_maker_portal.py

def calculate_earnings(some_var):
    # Correct f-string
    return f"This is a value: {some_var}"

def generate_pattern():
    # Corrected double braces for literal {}
    return f"(?:some_pattern){{0,2}}"
