# broski_money_maker_portal.py

def display_money_maker(data):
    newline = '\n'
    return f"{newline.join(data)}"
