import React from 'react';
export default function DreamForm() {
  return (
    <div className="mb-4">
      <textarea className="w-full p-2 text-black rounded" rows="4" placeholder="Describe your dream..."></textarea>
      <button className="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded mt-2">
        Send Dream
      </button>
    </div>
  );
}
