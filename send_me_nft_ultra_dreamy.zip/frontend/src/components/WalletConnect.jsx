import React from 'react';
export default function WalletConnect() {
  return <div className="mb-4">🔗 Connect your wallet here (Coming soon)</div>;
}
