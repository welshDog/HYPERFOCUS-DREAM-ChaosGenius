import React from 'react';
export default function FileUpload() {
  return (
    <div className="mb-4">
      <input type="file" className="mb-2" />
      <button className="bg-green-500 hover:bg-green-700 text-white font-bold py-2 px-4 rounded">
        Upload to IPFS
      </button>
    </div>
  );
}
