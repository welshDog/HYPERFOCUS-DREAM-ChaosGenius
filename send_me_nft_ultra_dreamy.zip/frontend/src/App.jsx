import React from 'react';
import WalletConnect from './components/WalletConnect';
import DreamForm from './components/DreamForm';
import FileUpload from './components/FileUpload';

function App() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-500 to-blue-600 text-white p-6">
      <h1 className="text-4xl font-bold mb-4">🌙 Send Me Your Dream</h1>
      <WalletConnect />
      <DreamForm />
      <FileUpload />
    </div>
  );
}

export default App;
