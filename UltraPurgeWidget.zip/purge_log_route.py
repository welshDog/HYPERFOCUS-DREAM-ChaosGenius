from flask import request, Response
import os

@app.route("/api/purge-log")
def show_log():
    auth = request.authorization
    if not auth or auth.password != os.getenv("ULTRA_LOG_PASSWORD", "changeme"):
        return Response(
            "Access denied. Please provide the admin password.", 401,
            {"WWW-Authenticate": 'Basic realm="Ultra Log Zone"'}
        )

    try:
        with open("cloudflare_purge.log", "r") as f:
            content = f.read()
        return f"<pre>{content}</pre>"
    except FileNotFoundError:
        return "No log file found."