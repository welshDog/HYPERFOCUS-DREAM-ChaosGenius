// components/PurgeLogWidget.jsx
import React, { useEffect, useState } from 'react';

const PurgeLogWidget = () => {
  const [logs, setLogs] = useState("");

  useEffect(() => {
    fetch("/api/purge-log", {
      headers: {
        Authorization: "Basic " + btoa("admin:YourSecretHere")
      }
    })
    .then(res => res.text())
    .then(data => setLogs(data))
    .catch(() => setLogs("❌ Failed to load logs."));
  }, []);

  return (
    <div className="bg-gray-900 text-green-300 p-4 rounded-xl shadow-md">
      <h2 className="text-lg font-bold mb-2">📜 Cloudflare Purge History</h2>
      <pre className="text-sm max-h-60 overflow-y-auto">{logs}</pre>
    </div>
  );
};

export default PurgeLogWidget;