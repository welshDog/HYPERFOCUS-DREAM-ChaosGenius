Agent Name | Style | Powers | Likes | Skills
--- | --- | --- | --- | ---
BROski X | Glitch Wizard | AI Boost, Flow Detect | Helping, Cheering | Markdown Wizardry, Dook Syncing