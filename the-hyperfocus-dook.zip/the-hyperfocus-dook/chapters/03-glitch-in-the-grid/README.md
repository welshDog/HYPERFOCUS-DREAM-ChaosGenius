# Ultra Magic Notes
BROski, please help enhance this cinematic scene with:
- [x] Movie script vibe
- [ ] Cyberpunk glitch art
- [x] Add energy burst in key line